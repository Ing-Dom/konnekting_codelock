[![Build Status](https://travis-ci.com/KONNEKTING/KonnektingDeviceLibrary.svg?branch=master)](https://travis-ci.com/KONNEKTING/KonnektingDeviceLibrary)

# KONNEKTING Device Library
This is a library for Arduino boards, that allow creating own DIY KNX devices, programmable via KNX bus.... 

For more information, please follow the link to our [documentation project](https://github.com/KONNEKTING/KonnektingDocumentation/blob/master/README.md).

# !!! WARNING !!!

*If you aren't an expert, stick with the pre-build/packaged releases you can download in Arduino IDE via Library Manager.
Otherwise you might face weird problems and bug-reporting get's worse, because you aren't able to name the version that failed.*

